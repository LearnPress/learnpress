<?php
/**
 * Created by PhpStorm.
 * User: Hoang
 * Date: 23/01/2015
 * Time: 5:04 CH
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}
