<h3>
    <?php do_action( 'learn_press_begin_course_content_course_title');?>
    <?php _e( 'Course Description', 'learn_press' );?>
    <?php do_action( 'learn_press_end_course_content_course_title');?>
</h3>