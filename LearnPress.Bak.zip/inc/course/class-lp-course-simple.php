<?php
class LP_Course_Simple extends LP_Course{

}